<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 1
    </div>
    <strong>ODP : Online Document Process for organization.</strong>
  </footer>