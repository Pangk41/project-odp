<div class="row">
    <div class="col-xs-4">
    </div>

    <div class="col-xs-4">
    </div>
                
    <div class="col-xs-4">
    </div>
</div>